@extends('layout.app')
@section('title','المرتبات')
@section('sub-title','الرئسية')
@section('content')
    <div class="row">
        <div class="col-md-12">
            <div class="box box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title">المرتبات</h3>
                    <div class="box-btn">
                        <!-- Button trigger modal -->
                        <button type="button" class="btn btn-primary btn-flat btn-sm" data-toggle="modal"
                                data-target="#modal">
                            <i class="fa fa-calendar"></i>
                        </button>
                        <!-- Modal -->
                        <div class="modal fade" id="modal" tabindex="-1" role="dialog" aria-labelledby="modalLabel">
                            <div class="modal-dialog modal-lg" role="document">
                                <div class="modal-content">
                                    <form class="validate">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span></button>
                                            <h4 class="modal-title" id="modalLabel"> اختر التاريخ</h4>
                                        </div>
                                        <div class="modal-body">
                                            <div class="row">
                                                <div class="col-sm-12">
                                                    <div class="form-group">
                                                        <label for="date">التاريخ</label>
                                                        <input type="text" id="date" required class="form-control date"
                                                               name="date"
                                                               value="{{Carbon\Carbon::now()->toDateString()}}">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-default btn-sm btn-flat"
                                                    data-dismiss="modal">الغاء
                                            </button>
                                            <button type="submit" id="accept" class="btn btn-primary btn-sm btn-flat">
                                                موافق
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.box-header -->
                <div class="box-body">
                    <div class="table-responsive" style="overflow: auto">
                        <form>
                            {!! $dataTable->table(['class' => 'table table-bordered']) !!}
                        </form>

                    </div>
                </div>

                <!-- /.box-body -->

            </div>
            <!-- /.box -->
        </div>

    </div>
@stop


@push('scripts')
    <script>


        var $modal = $('#modal');
        var $settingModal = $('#settingsModal');
        var $accept = $('#accept')
        var $date = $('#date');
        var date = '{{Carbon\Carbon::now()->toDateString()}}';
        var $dateForm = $('.validate');
        var $table = $('.table');

        $(document).ready(function () {
            $dateForm.validate();
            $dateForm.on('submit', function (e) {
                e.preventDefault();
                if ($dateForm.valid()) {
                    date = $date.val();
                    $table.DataTable().clear().draw();
                    $modal.modal('hide');
                }
            })


            $(document).on('click', '.perform-save', function (e) {

                e.preventDefault();

                id = $(this).data('employee-id');


                if ($(`.validate-salary-${id}`).valid()) {

                    basic = $(`#salary-${id}-basic`).val();
                    bonus = $(`#salary-${id}-bonus`).val();
                    financialPenalities = $(`#salary-${id}-financial-penalties`).val();
                    loans = $(`#salary-${id}-loans`).val();
                    madionia = $(`#salary-${id}-madionia`).val();
                    transports = $(`#salary-${id}-transports`).val();
                    insurance = $(`#salary-${id}-insurance`).val();
                    console.log(id, Number(transports), loans, financialPenalities, bonus);
                    $.ajax({
                        url: '{{route("api.salary.perform-save")}}',
                        type: 'POST',
                        data: {
                            employee_id: id,
                            date: $date.val(),
                            basic: basic,
                            bonus: bonus,
                            financial_penalties: financialPenalities,
                            loans: loans,
                            madionia: madionia,
                            transports: transports,
                            insurance: insurance
                        }, success: function (data) {
                            console.log(data);
                            $table.DataTable().clear().draw();
                            iziToast.success({
                                timeout: 1000,
                                transitionIn: 'flipInX',
                                transitionOut: 'flipOutX',
                                position: 'bottomLeft',
                                rtl: true,
                                message: 'تم التعديل بنجاح ',
                            });
                        },
                        error: function () {

                        }
                    })
                }

            })

        })
    </script>
@endpush


@push('scripts')
    <script src="{{asset('vendor/datatables/buttons.server-side.js')}}"></script>
    {!! $dataTable->scripts() !!}
@endpush