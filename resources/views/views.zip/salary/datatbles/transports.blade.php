<div class="form-group">
    <input type="text" readonly class="validate-salary-{{$id}} form-control input-sm number"   value="{{$transports}}" required  placeholder="{{$transports}}" id="salary-{{$id}}-transports">
</div>