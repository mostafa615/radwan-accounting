<div class="form-group">
    <input type="text"  value="{{$basic}}" required
           class="validate-salary-{{$id}} form-control input-sm number"
           id="salary-{{$id}}-basic">
</div>