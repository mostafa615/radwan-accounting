<div class="form-group">
        <input type="text"  value="{{$bonus?$bonus:'0'}}" required  class="validate-salary-{{$id}} form-control input-sm number" id="salary-{{$id}}-bonus">
        </div>