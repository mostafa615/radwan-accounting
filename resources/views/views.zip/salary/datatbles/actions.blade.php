<button data-employee-id="{{$id}}" class="perform-save btn btn-sm bg-black btn-flat">
    <i class="fa fa-check"></i>
</button>