<div class="form-group">
    <input type="text"  value="{{$insurance?$insurance:'0'}}" required class=" validate-salary-{{$id}} form-control input-sm number" id="salary-{{$id}}-insurance">
</div>