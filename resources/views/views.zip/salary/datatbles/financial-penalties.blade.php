<div class="form-group">
        <input type="text"  value="{{$financialPenalties?$financialPenalties:'0'}}" required class=" validate-salary-{{$id}} form-control input-sm number" id="salary-{{$id}}-financial-penalties">
</div>