<div class="form-group">
    <input type="text" class="form-control input-sm number validate-salary-{{$id}}"  value="{{$loans}}" required  placeholder="{{$loans}}" id="salary-{{$id}}-madionia">
</div>